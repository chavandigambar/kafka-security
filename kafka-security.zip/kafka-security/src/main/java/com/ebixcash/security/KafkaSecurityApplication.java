package com.ebixcash.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaSecurityApplication.class, args);
	}

}
